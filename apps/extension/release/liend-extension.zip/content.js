"use strict";(()=>{var K=/^0x[a-fA-F0-9]{40}$/;function I(e){return typeof e=="string"&&K.test(e)}var O="liend-trigger-root";function F(e){let t=document.getElementById(O);t&&t.remove();let r=document.createElement("div");r.id=O,r.style.cssText=["position:fixed","left:16px","bottom:16px","z-index:2147483000","width:auto","height:auto","pointer-events:none"].join(";");let l=r.attachShadow({mode:"closed"}),i=document.createElement("style");i.textContent=`
    .liend-trigger {
      pointer-events: auto;
      isolation: isolate;
      display: inline-flex;
      overflow: hidden;
      align-items: center;
      gap: 8px;
      height: 36px;
      padding: 0 14px;
      border: 2px solid rgba(196, 255, 188, 0.62);
      border-radius: 3px;
      background:
        linear-gradient(180deg, rgba(186, 255, 178, 0.38) 0%, rgba(77, 255, 90, 0.2) 46%, rgba(12, 48, 24, 0.55) 100%);
      color: #f4fff6;
      font: 400 10px/1 Silkscreen, "Press Start 2P", "IBM Plex Mono", ui-monospace, monospace;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      cursor: pointer;
      box-shadow:
        inset 1px 1px 0 rgba(255, 255, 255, 0.58),
        inset -1px -1px 0 rgba(8, 40, 16, 0.42),
        4px 6px 0 rgba(4, 10, 40, 0.45);
    }
    .liend-trigger::before {
      position: absolute;
      inset: 0;
      background: linear-gradient(180deg, rgba(255,255,255,0.38) 0%, rgba(255,255,255,0.06) 32%, transparent 58%);
      content: "";
      pointer-events: none;
    }
    .liend-trigger { position: relative; }
    .liend-trigger:hover { border-color: rgba(220, 255, 214, 0.88); }
    .liend-trigger:focus-visible { outline: 2px solid #4dff5a; outline-offset: 2px; }
    .dot {
      width: 7px;
      height: 7px;
      border-radius: 50%;
      background: #4dff5a;
      box-shadow: 0 0 8px rgba(77, 255, 90, 0.7);
    }
    @media (prefers-reduced-motion: reduce) { .liend-trigger { transition: none; } }
  `;let s=document.createElement("button");s.type="button",s.className="liend-trigger",s.setAttribute("aria-label","Open LONS liquidity panel");let d=document.createElement("span");d.className="dot";let c=document.createElement("span");return c.textContent="LONS \xB7 Check liquidity",s.append(d,c),s.addEventListener("click",p=>{p.preventDefault(),p.stopPropagation(),e()}),l.append(i,s),document.documentElement.append(r),()=>{r.remove()}}var P=new Set(["ponsfamily.com","www.ponsfamily.com"]);function Q(e){let t=e.length;for(;t>0&&e[t-1]==="/";)t-=1;return e.slice(0,t)}function N(e){let t=e.split("/").filter(Boolean);return t.length<2||t[0]!=="launchpad"?null:I(t[1])?t[1]:null}function $(e){if(!e)return null;try{let t=new URL(e);return P.has(t.hostname)?N(t.pathname):null}catch{return null}}function J(e){let t=e.querySelector('link[rel="canonical"]');return $(t?.href??null)}function W(e){let t=e.querySelector('meta[property="og:url"]');return $(t?.content??null)}function Y(e,t,r=!1){let l=N(e.pathname);if(!l)return{status:"none"};let i={source:"pons",chain:"robinhood",mint:l,pageUrl:`${e.origin}${e.pathname}`,detectedAt:Date.now()};return[J(t),W(t)].filter(c=>c!==null).some(c=>c!==l)?r?{status:"token",context:i,confidence:"url-only"}:{status:"pending"}:{status:"token",context:i,confidence:"corroborated"}}var H={id:"pons",matches(e){return P.has(e.hostname)},identify(e){let t=N(e.pathname);return t?`pons:${t}`:`pons:route:${Q(e.pathname)||"/"}`},detect(e,t,r){return Y(e,t,r)},observeNavigation(e){let t=()=>e(),r=history.pushState,l=history.replaceState;return history.pushState=function(...i){let s=r.apply(this,i);return t(),s},history.replaceState=function(...i){let s=l.apply(this,i);return t(),s},window.addEventListener("popstate",t),()=>{history.pushState=r,history.replaceState=l,window.removeEventListener("popstate",t)}},mountTrigger(e){return F(e)}};var Z=[H];function G(e){return Z.find(t=>t.matches(e))??null}var S=[0,250,600,1e3],ee=900,B=1500;function q(e){let t=e.setTimeoutFn??((n,o)=>setTimeout(n,o)),r=e.clearTimeoutFn??(n=>clearTimeout(n)),l=e.now??(()=>Date.now()),i=0,s=null,d=0,c=!0,p=null,y=null,b=!1;function g(){p!==null&&(r(p),p=null),y!==null&&(r(y),y=null)}function m(n){e.events.onDiagnostic?.({generation:i,identity:s??"",attempt:-1,elapsedFromT0:l()-d,urlMint:null,canonicalMint:null,ogMint:null,...n})}function L(n,o,a,u,D){c=!0,g(),m({attempt:D,urlMint:n.context.mint,decision:"accepted",confidence:n.confidence,reason:u}),e.events.onToken(n.context,n.confidence,a,o)}function A(n,o,a,u){c=!0,g(),m({attempt:u,decision:"rejected",reason:a}),e.events.onNone(o,n)}function x(n,o,a){c=!0,g(),m({decision:"failed",reason:a}),e.events.onFailed(a,o,n)}function R(n){try{return e.adapter.detect(e.getUrl(),e.getDocument(),n)}catch{return null}}function U(n,o,a){if(b||c||n!==i)return;let D=l()-d>=ee,M;try{M=e.adapter.identify(e.getUrl())}catch{x(n,a,"unreadable-url");return}if(M!==a)return;let T=R(D);if(T===null){x(n,a,"adapter-threw");return}if(T.status==="token"){L(T,n,a,D?"grace-expired-url-authoritative":"evidence-consistent",o);return}if(T.status==="none"){A(n,a,"not-a-token-route",o);return}m({attempt:o,decision:"pending",reason:"metadata-contradicts-url"});let E=o+1;if(E<S.length&&S[E]<B){let X=S[E]-S[o];p=t(()=>U(n,E,a),X)}}function V(n,o){if(b||c||n!==i)return;let a=R(!0);if(a===null){x(n,o,"deadline-adapter-threw");return}if(a.status==="token"){L(a,n,o,"deadline-url-fallback",-1);return}A(n,o,"deadline-no-token",-1)}function z(n,o,a){i+=1;let u=i;s=n,d=l(),c=!1,g(),y=t(()=>V(u,n),B),a&&e.events.onNavigating(`${o.origin}${o.pathname}`,n,u),U(u,0,n)}function _(n){if(b)return;let o,a;try{o=e.getUrl(),a=e.adapter.identify(o)}catch{x(i,s??"","unreadable-url");return}if(a===s){m({decision:"ignored-duplicate",reason:c?"already-resolved":"cycle-in-flight"});return}z(a,o,n)}return{start:()=>_(!1),onNavigation:()=>_(!0),dispose:()=>{b=!0,c=!0,g()},currentGeneration:()=>i,currentIdentity:()=>s}}var w=null,h=null,k=null,C=null;function f(e){try{chrome.runtime.sendMessage(e,()=>{chrome.runtime.lastError})}catch{}}function v(){C&&(C(),C=null)}function j(){let e=new URL(location.href);if(w=G(e),!w)return;let t=w;h=q({adapter:t,getUrl:()=>new URL(location.href),getDocument:()=>document,events:{onDiagnostic:r=>{},onNavigating:(r,l,i)=>{v(),f({type:"NAVIGATION_STARTED",source:t.id,pageUrl:r,identity:l,generation:i})},onToken:(r,l,i,s)=>{v(),C=t.mountTrigger(()=>f({type:"REQUEST_PANEL_OPEN"})),f({type:"TOKEN_CONTEXT",context:r,identity:i,generation:s})},onNone:(r,l)=>{v(),f({type:"CONTEXT_CLEARED",source:t.id,identity:r,generation:l})},onFailed:(r,l,i)=>{v(),f({type:"DETECTION_FAILED",source:t.id,identity:l,generation:i})}}}),k=t.observeNavigation(()=>h?.onNavigation()),h.start()}function te(){k?.(),k=null,h?.dispose(),h=null,v(),w=null}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",j,{once:!0}):j();window.addEventListener("pagehide",te,{once:!0});})();
