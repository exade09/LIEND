"use strict";(()=>{var K=/^0x[a-fA-F0-9]{40}$/;function O(e){return typeof e=="string"&&K.test(e)}var F="lons-trigger-root";function I(e){let t=document.getElementById(F);t&&t.remove();let r=document.createElement("div");r.id=F,r.style.cssText=["position:fixed","left:16px","bottom:16px","z-index:2147483000","width:auto","height:auto","pointer-events:none"].join(";");let s=r.attachShadow({mode:"closed"}),i=document.createElement("style");i.textContent=`
    .lons-trigger {
      pointer-events: auto;
      isolation: isolate;
      display: inline-flex;
      overflow: hidden;
      align-items: center;
      gap: 9px;
      min-height: 40px;
      padding: 0 16px 0 10px;
      border: 1px solid rgba(42, 66, 47, 0.32);
      border-radius: 999px;
      background:
        linear-gradient(135deg, rgba(255, 255, 250, 0.96), rgba(231, 240, 220, 0.9));
      color: #263528;
      font: 600 11px/1.1 "IBM Plex Mono", "Cascadia Mono", ui-monospace, monospace;
      letter-spacing: 0.02em;
      cursor: pointer;
      backdrop-filter: blur(18px) saturate(1.12);
      box-shadow:
        inset 0 1px 0 rgba(255, 255, 255, 0.95),
        0 10px 28px rgba(36, 61, 39, 0.2);
      transition: transform 180ms ease, box-shadow 180ms ease, border-color 180ms ease;
    }
    .lons-trigger::before {
      position: absolute;
      inset: 0;
      border-radius: inherit;
      background: linear-gradient(180deg, rgba(255,255,255,0.48), transparent 56%);
      content: "";
      pointer-events: none;
    }
    .lons-trigger { position: relative; }
    .lons-trigger:hover {
      border-color: rgba(69, 111, 73, 0.58);
      box-shadow: inset 0 1px 0 #fff, 0 14px 34px rgba(36, 61, 39, 0.25);
      transform: translateY(-2px);
    }
    .lons-trigger:focus-visible { outline: 3px solid rgba(166, 220, 136, 0.75); outline-offset: 3px; }
    .mark {
      position: relative;
      width: 20px;
      height: 20px;
      border: 1px solid rgba(54, 91, 58, 0.35);
      border-radius: 50%;
      background:
        radial-gradient(circle at 34% 28%, #fff 0 12%, transparent 14%),
        conic-gradient(from 28deg, #fafff6, #a9cf9d, #f4fff0, #bdd8b5, #fafff6);
      box-shadow: inset 0 0 0 4px rgba(255,255,255,.48), 0 3px 8px rgba(46, 77, 49, .2);
    }
    .mark::after {
      position: absolute;
      inset: 5px;
      border: 1px solid rgba(41, 72, 44, .45);
      border-radius: 50%;
      content: "";
    }
    @media (prefers-reduced-motion: reduce) { .lons-trigger { transition: none; } }
  `;let l=document.createElement("button");l.type="button",l.className="lons-trigger",l.setAttribute("aria-label","Open Lons liquidity panel");let d=document.createElement("span");d.className="mark";let c=document.createElement("span");return c.textContent="Lons \xB7 Check liquidity",l.append(d,c),l.addEventListener("click",p=>{p.preventDefault(),p.stopPropagation(),e()}),s.append(i,l),document.documentElement.append(r),()=>{r.remove()}}var $=new Set(["ponsfamily.com","www.ponsfamily.com"]);function Q(e){let t=e.length;for(;t>0&&e[t-1]==="/";)t-=1;return e.slice(0,t)}function C(e){let t=e.split("/").filter(Boolean);return t.length<2||t[0]!=="launchpad"?null:O(t[1])?t[1]:null}function P(e){if(!e)return null;try{let t=new URL(e);return $.has(t.hostname)?C(t.pathname):null}catch{return null}}function Y(e){let t=e.querySelector('link[rel="canonical"]');return P(t?.href??null)}function J(e){let t=e.querySelector('meta[property="og:url"]');return P(t?.content??null)}function W(e,t,r=!1){let s=C(e.pathname);if(!s)return{status:"none"};let i={source:"pons",chain:"robinhood",mint:s,pageUrl:`${e.origin}${e.pathname}`,detectedAt:Date.now()};return[Y(t),J(t)].filter(c=>c!==null).some(c=>c!==s)?r?{status:"token",context:i,confidence:"url-only"}:{status:"pending"}:{status:"token",context:i,confidence:"corroborated"}}var H={id:"pons",matches(e){return $.has(e.hostname)},identify(e){let t=C(e.pathname);return t?`pons:${t}`:`pons:route:${Q(e.pathname)||"/"}`},detect(e,t,r){return W(e,t,r)},observeNavigation(e){let t=()=>e(),r=history.pushState,s=history.replaceState;return history.pushState=function(...i){let l=r.apply(this,i);return t(),l},history.replaceState=function(...i){let l=s.apply(this,i);return t(),l},window.addEventListener("popstate",t),()=>{history.pushState=r,history.replaceState=s,window.removeEventListener("popstate",t)}},mountTrigger(e){return I(e)}};var Z=[H];function G(e){return Z.find(t=>t.matches(e))??null}var S=[0,250,600,1e3],ee=900,B=1500;function q(e){let t=e.setTimeoutFn??((n,o)=>setTimeout(n,o)),r=e.clearTimeoutFn??(n=>clearTimeout(n)),s=e.now??(()=>Date.now()),i=0,l=null,d=0,c=!0,p=null,h=null,x=!1;function g(){p!==null&&(r(p),p=null),h!==null&&(r(h),h=null)}function m(n){e.events.onDiagnostic?.({generation:i,identity:l??"",attempt:-1,elapsedFromT0:s()-d,urlMint:null,canonicalMint:null,ogMint:null,...n})}function N(n,o,a,u,D){c=!0,g(),m({attempt:D,urlMint:n.context.mint,decision:"accepted",confidence:n.confidence,reason:u}),e.events.onToken(n.context,n.confidence,a,o)}function A(n,o,a,u){c=!0,g(),m({attempt:u,decision:"rejected",reason:a}),e.events.onNone(o,n)}function y(n,o,a){c=!0,g(),m({decision:"failed",reason:a}),e.events.onFailed(a,o,n)}function R(n){try{return e.adapter.detect(e.getUrl(),e.getDocument(),n)}catch{return null}}function U(n,o,a){if(x||c||n!==i)return;let D=s()-d>=ee,M;try{M=e.adapter.identify(e.getUrl())}catch{y(n,a,"unreadable-url");return}if(M!==a)return;let T=R(D);if(T===null){y(n,a,"adapter-threw");return}if(T.status==="token"){N(T,n,a,D?"grace-expired-url-authoritative":"evidence-consistent",o);return}if(T.status==="none"){A(n,a,"not-a-token-route",o);return}m({attempt:o,decision:"pending",reason:"metadata-contradicts-url"});let E=o+1;if(E<S.length&&S[E]<B){let X=S[E]-S[o];p=t(()=>U(n,E,a),X)}}function V(n,o){if(x||c||n!==i)return;let a=R(!0);if(a===null){y(n,o,"deadline-adapter-threw");return}if(a.status==="token"){N(a,n,o,"deadline-url-fallback",-1);return}A(n,o,"deadline-no-token",-1)}function z(n,o,a){i+=1;let u=i;l=n,d=s(),c=!1,g(),h=t(()=>V(u,n),B),a&&e.events.onNavigating(`${o.origin}${o.pathname}`,n,u),U(u,0,n)}function _(n){if(x)return;let o,a;try{o=e.getUrl(),a=e.adapter.identify(o)}catch{y(i,l??"","unreadable-url");return}if(a===l){m({decision:"ignored-duplicate",reason:c?"already-resolved":"cycle-in-flight"});return}z(a,o,n)}return{start:()=>_(!1),onNavigation:()=>_(!0),dispose:()=>{x=!0,c=!0,g()},currentGeneration:()=>i,currentIdentity:()=>l}}var w=null,v=null,L=null,k=null;function f(e){try{chrome.runtime.sendMessage(e,()=>{chrome.runtime.lastError})}catch{}}function b(){k&&(k(),k=null)}function j(){let e=new URL(location.href);if(w=G(e),!w)return;let t=w;v=q({adapter:t,getUrl:()=>new URL(location.href),getDocument:()=>document,events:{onDiagnostic:r=>{},onNavigating:(r,s,i)=>{b(),f({type:"NAVIGATION_STARTED",source:t.id,pageUrl:r,identity:s,generation:i})},onToken:(r,s,i,l)=>{b(),k=t.mountTrigger(()=>f({type:"REQUEST_PANEL_OPEN"})),f({type:"TOKEN_CONTEXT",context:r,identity:i,generation:l})},onNone:(r,s)=>{b(),f({type:"CONTEXT_CLEARED",source:t.id,identity:r,generation:s})},onFailed:(r,s,i)=>{b(),f({type:"DETECTION_FAILED",source:t.id,identity:s,generation:i})}}}),L=t.observeNavigation(()=>v?.onNavigation()),v.start()}function te(){L?.(),L=null,v?.dispose(),v=null,b(),w=null}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",j,{once:!0}):j();window.addEventListener("pagehide",te,{once:!0});})();
